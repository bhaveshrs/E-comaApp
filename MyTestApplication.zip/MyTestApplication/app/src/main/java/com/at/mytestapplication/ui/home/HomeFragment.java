package com.at.mytestapplication.ui.home;

import static com.at.mytestapplication.Registration.PREFS_NAME;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.at.mytestapplication.R;
import com.at.mytestapplication.SliderAdapter;
import com.at.mytestapplication.SliderData;
import com.at.mytestapplication.databinding.FragmentHomeBinding;
import com.smarteist.autoimageslider.IndicatorView.animation.type.IndicatorAnimationType;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    SliderView slider;

    ArrayList<SliderData> sliderDataArrayList;
    SliderAdapter sliderAdapter;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    String username,password;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        slider = root.findViewById(R.id.slider);

        sharedPreferences = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        username = sharedPreferences.getString("username","");
        password = sharedPreferences.getString("password","");

        sliderDataArrayList = new ArrayList<>();
        sliderAdapter = new SliderAdapter(getContext(),getActivity(),sliderDataArrayList);

        getbannerimage();

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void getbannerimage()
    {
        String pincode = "";
        String url =    "https://urmilkman.com/apppanel/res/wsgetbanner.php?p1=" + username.replace(" ", "%20") + "&p2=" + password.replace(" ", "%20") + "&p3=" + pincode.replace(" ", "%20");

        Log.e("cs","url=>"+url);

        sliderDataArrayList.clear();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                if(response!=null)
                {
                    Log.e("cs","response=>"+response.toString());
                    try {
                        JSONArray jsonArray = response.getJSONArray("item");
                        for(int i=0;i<jsonArray.length();i++)
                        {
                            JSONObject j2 = jsonArray.getJSONObject(i);
                            if(j2.getString("p1").equals("1"))
                            {
                                SliderData sliderData = new SliderData();
                                sliderData.setImgurl("https://urmilkman.com/apppanel/images/"+j2.getString("p3"));

                                sliderDataArrayList.add(sliderData);

                               // sliderDataArrayList.add(new SliderData(j2.getString("p3")));
                            }
                            else
                            {
                                Toast.makeText(requireContext(),"No Images",Toast.LENGTH_LONG).show();
                            }
                        }
                        slider.setSliderAdapter(sliderAdapter);
                       /* slider.setScrollTimeInSec(5);
                        slider.setIndicatorEnabled(true);

                        // to set it scrollable automatically
                        // we use below method.
                        slider.setAutoCycle(true);
                        slider.setIndicatorAnimation(IndicatorAnimationType.WORM); //set indicator animation by using IndicatorAnimationType. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
                        slider.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
                        slider.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
*/
                        // to start autocycle below method is used.
                        slider.startAutoCycle();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(requireContext(),"There was some issue.Please try after some time.",Toast.LENGTH_LONG).show();
                    }
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(requireContext(),"There was some issue.Please try after some time.",Toast.LENGTH_LONG).show();
            }
        });

        Volley.newRequestQueue(requireContext()).add(jsonObjectRequest);
    }
}