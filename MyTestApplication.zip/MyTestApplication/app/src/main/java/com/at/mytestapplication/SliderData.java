package com.at.mytestapplication;

public class SliderData {
    String imgurl;

    public SliderData() {

    }

    public SliderData(String imgurl) {
        this.imgurl = imgurl;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }
}
